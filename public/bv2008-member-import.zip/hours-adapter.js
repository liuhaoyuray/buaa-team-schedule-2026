(() => {
  if (globalThis.__buaaHoursAdapter) return;
  const {
    clean,
    visible,
    find,
    enabled,
    fill,
    wait,
    waitStable,
    isLoading,
    timing,
    submitAndWait,
    readGroup,
  } = globalThis.__buaaMemberAdapter;
  const { lookup, verifyName, displayedValue, sameTarget } =
    globalThis.__buaaActivityAdapter;
  const route = "#/projectActivityManage/myProject/durationInput";
  const result = (status, reason) => ({ status, reason });
  let busy = false;
  let proof = null;
  let lastNumber = "";
  const projectCache = new Map();
  async function nativeProject(message) {
    const requestId = crypto.randomUUID();
    let receive, timer;
    try {
      return await new Promise((resolve) => {
        receive = (event) => {
          let value;
          try {
            value = JSON.parse(event.detail);
          } catch {
            return;
          }
          if (value.requestId === requestId) resolve(value);
        };
        document.addEventListener("buaa-hours-native-result", receive);
        timer = setTimeout(
          () =>
            resolve({
              status: message.action === "commit" ? "unknown" : "blocked",
              reason:
                message.action === "commit"
                  ? "项目审批响应超时，请核对官网导入记录。"
                  : "官网项目查询超时，已保留进度。",
            }),
          120000,
        );
        document.dispatchEvent(
          new CustomEvent("buaa-hours-native-request", {
            detail: JSON.stringify({ ...message, requestId }),
          }),
        );
      });
    } finally {
      clearTimeout(timer);
      document.removeEventListener("buaa-hours-native-result", receive);
    }
  }
  const projectKey = (target) =>
    [target.id, target.activityId, target.postId].join("|");
  async function targetStatus() {
    const current = target();
    if (!current.id) return { ...current, busy };
    const key = projectKey(current);
    const cached = projectCache.get(key);
    if (cached && Date.now() - cached.at < 60000)
      return { ...current, ...cached.value, busy };
    const requestId = crypto.randomUUID();
    let receive, timer;
    try {
      const metadata = await new Promise((resolve) => {
        receive = (event) => {
          let data;
          try {
            data = JSON.parse(event.detail);
          } catch {
            return;
          }
          if (data.requestId === requestId) resolve(data);
        };
        document.addEventListener("buaa-hours-project-result", receive);
        timer = setTimeout(
          () =>
            resolve({
              reason: "读取项目信息超时，可点重新检查；也可手动补充。",
            }),
          12000,
        );
        document.dispatchEvent(
          new CustomEvent("buaa-hours-project-request", {
            detail: JSON.stringify({ ...current, requestId }),
          }),
        );
      });
      if (!sameTarget(target(), current))
        return { reason: "读取期间活动已切换，请重新检查。" };
      const dates = (metadata.dates || [])
        .filter((date) => /^\d{4}-\d{2}-\d{2}$/.test(date))
        .sort();
      const value = {
        activityName: metadata.activityName || "",
        postName: metadata.postName || "",
        posts: Array.isArray(metadata.posts) ? metadata.posts : [],
        dates,
        metadataReason: metadata.reason || "",
      };
      if (value.activityName && dates.length)
        projectCache.set(key, { at: Date.now(), value });
      return { ...current, ...value, busy };
    } finally {
      clearTimeout(timer);
      document.removeEventListener("buaa-hours-project-result", receive);
    }
  }
  function target() {
    const [page, query] = location.hash.split("?");
    const params = new URLSearchParams(query);
    const group = readGroup();
    if (
      page !== route ||
      !group ||
      !params.get("activityId") ||
      !params.get("postId") ||
      params.get("fromSettings") === "1" ||
      (params.get("orgId") && params.get("orgId") !== group.id) ||
      ![...document.querySelectorAll(".DurationInputList")].some(visible)
    ) {
      return { reason: "请打开目标活动岗位的「计时 → 时长录入」页面。" };
    }
    return {
      ...group,
      activityId: params.get("activityId"),
      postId: params.get("postId"),
    };
  }
  const changed = (expected) =>
    location.hash.split("?")[0] !== route ||
    (target().id && !sameTarget(target(), expected));
  const dialog = () =>
    [...document.querySelectorAll('.ant-modal, [role="dialog"]')]
      .filter(visible)
      .find((form) => form.querySelector('input[placeholder="请输入时长"]'));
  async function close(form) {
    const cancel = find(form, "button", "取消");
    if (cancel && enabled(cancel)) cancel.click();
    return waitStable(
      () => !form.isConnected || !visible(form),
      timing.page,
      180,
    );
  }
  async function open(person, expected) {
    if (changed(expected)) throw Error("目标团体、活动或岗位已改变。");
    if (dialog()) throw Error("请先关闭官网的录时长弹窗。");
    const page = [...document.querySelectorAll(".DurationInputList")].find(
      visible,
    );
    if (!page) throw Error("请切到官网的「时长录入」页签。");
    const found = await lookup(page, person, expected, true, target);
    if (!found || found.changed)
      throw Error("官网人员检索尚未完成，请稍后继续。");
    if (found.total !== 1 || found.rows.length !== 1)
      throw Object.assign(
        Error(
          found.total > 1
            ? "当前岗位有重名人员，请补充志愿者编号或证件号码；此人未提交。"
            : "未在当前岗位找到匹配的志愿者。",
        ),
        {
          personIssue: true,
        },
      );
    const row = found.rows[0];
    if (
      person.identifier === "number" &&
      displayedValue(found.table, row, "志愿者编号") !== person.cert
    )
      throw Error("志愿者编号不一致。");
    if (!(await verifyName(row, person.name)))
      throw Object.assign(Error("姓名不一致，请核对名单。"), {
        personIssue: true,
      });
    lastNumber = displayedValue(found.table, row, "志愿者编号");
    if (!lastNumber) throw Error("未能读取志愿者编号，请等待官网名单加载。");
    const actions = [...row.querySelectorAll("a,button")].filter(
      (el) => visible(el) && /^(录入|调整|计时)$/.test(clean(el.textContent)),
    );
    if (actions.length !== 1 || !found.unchanged())
      throw Error("无法确认这个人的录时长入口。");
    actions[0].click();
    const form = await waitStable(
      () => {
        const form = dialog();
        return form && !isLoading(form) && enabled(find(form, "button", "确定"))
          ? form
          : null;
      },
      timing.page,
      300,
    );
    if (!form) throw Error("录时长表单仍在加载。");
    return form;
  }
  function dateControl(form) {
    const item = [...form.querySelectorAll(".ant-form-item")].find((item) =>
      clean(item.querySelector("label")?.textContent)
        .replace(/[：:*]/g, "")
        .match(/^(?:服务)?日期$/),
    );
    return (
      item?.querySelector(".ant-select-selector") ||
      form.querySelector(".ant-select-selector")
    );
  }
  async function scanDates(form, wanted) {
    const control = dateControl(form);
    if (!control) throw Error("无法识别服务日期选择框。");
    const input =
      control.querySelector('input[role="combobox"],input') ||
      control
        .closest(".ant-select")
        ?.querySelector('input[role="combobox"],input');
    const trigger = input || control;
    if (trigger.getAttribute("aria-expanded") !== "true") {
      trigger.focus({ preventScroll: true });
      // Ant Design opens its select on mousedown, not programmatic click alone.
      trigger.dispatchEvent(
        new MouseEvent("mousedown", {
          button: 0,
          buttons: 1,
          bubbles: true,
          cancelable: true,
        }),
      );
      trigger.dispatchEvent(
        new MouseEvent("mouseup", {
          button: 0,
          bubbles: true,
          cancelable: true,
        }),
      );
      trigger.click();
    }
    const menu = await wait(() => {
      const owned = document
        .getElementById(trigger.getAttribute("aria-controls"))
        ?.closest(".ant-select-dropdown");
      if (owned && visible(owned)) return owned;
      const menus = [
        ...document.querySelectorAll(".ant-select-dropdown"),
      ].filter(visible);
      return menus.length === 1 ? menus[0] : null;
    }, timing.page);
    if (!menu) throw Error("服务日期仍在加载。");
    const dismiss = () => {
      trigger.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Escape",
          code: "Escape",
          keyCode: 27,
          bubbles: true,
        }),
      );
      document.body.dispatchEvent(
        new MouseEvent("mousedown", { bubbles: true }),
      );
    };
    if (
      !(await waitStable(
        () =>
          [...menu.querySelectorAll(".ant-select-item-option")].some((option) =>
            /^\d{4}-\d{2}-\d{2}/.test(
              clean(option.getAttribute("title") || option.textContent),
            ),
          ),
        timing.page,
        160,
      ))
    ) {
      dismiss();
      throw Error("官网没有返回可用服务日期，请重新检查活动日期。");
    }
    const holder = menu.querySelector(".rc-virtual-list-holder");
    if (holder) {
      holder.scrollTop = 0;
      holder.dispatchEvent(new Event("scroll"));
    }
    const dates = new Map();
    for (let step = 0; step < 150; step++) {
      await new Promise((resolve) => setTimeout(resolve, 80));
      for (const option of menu.querySelectorAll(".ant-select-item-option")) {
        const label = clean(option.getAttribute("title") || option.textContent);
        const date = label.match(/^\d{4}-\d{2}-\d{2}/)?.[0];
        if (!date) continue;
        const free =
          label === date &&
          !option.classList.contains("ant-select-item-option-disabled");
        dates.set(date, free);
        if (date === wanted) {
          if (!free) {
            dismiss();
            return { occupied: true };
          }
          option.click();
          const selected = await waitStable(
            () => {
              const value = clean(
                control
                  .querySelector(".ant-select-selection-item")
                  ?.getAttribute("title") ||
                  control.querySelector(".ant-select-selection-item")
                    ?.textContent ||
                  input?.value,
              );
              return value.startsWith(wanted) && !isLoading(form);
            },
            timing.page,
            250,
          );
          if (!selected) throw Error("官网日期选择尚未生效，已暂停，未提交。");
          return { selected: true };
        }
      }
      if (
        !holder ||
        holder.scrollTop + holder.clientHeight >= holder.scrollHeight - 1
      )
        break;
      holder.scrollTop += holder.clientHeight * 0.85;
      holder.dispatchEvent(new Event("scroll"));
    }
    dismiss();
    if (wanted) throw Error("这个服务日期不在官网可选范围内。");
    if (!dates.size) throw Error("没有读到可用的服务日期。");
    return {
      dates: [...dates].filter(([, free]) => free).map(([date]) => date),
    };
  }
  async function handle(message) {
    if (message.type === "hours-target") return targetStatus();
    if (message.type === "hours-project") {
      if (busy) return result("blocked", "另一个计时操作正在处理。");
      busy = true;
      try {
        return await nativeProject(message);
      } finally {
        busy = false;
      }
    }
    if (message.type === "hours-proof") {
      proof = message.proof;
      return { ok: true };
    }
    if (message.type?.startsWith("hours-batch-")) {
      if (busy) return result("blocked", "另一个计时操作正在处理。");
      busy = true;
      try {
        return await globalThis.__buaaHoursBatchAdapter.handle(message);
      } finally {
        busy = false;
      }
    }
    if (!["hours-prepare", "hours-submit"].includes(message.type)) return null;
    if (busy) return result("blocked", "另一个计时操作正在处理。");
    busy = true;
    let form;
    let clicked = false;
    try {
      form = await open(message.person, message.target);
      const scanned = await scanDates(form, message.date);
      if (message.type === "hours-prepare") {
        await close(form);
        return { ...scanned, number: lastNumber };
      }
      if (scanned.occupied) {
        await close(form);
        return result("existing", "这一天已有记录，已避开");
      }
      const field = form.querySelector('input[placeholder="请输入时长"]');
      const notes = form.querySelector(
        'textarea[placeholder="请输入备注信息"]',
      );
      if (!(await waitStable(() => !isLoading(form), timing.page, 350)))
        throw Error("日期记录仍在加载。");
      if (
        field.value ||
        notes?.value ||
        form.querySelector(".ant-upload-list-item")
      ) {
        await close(form);
        return result("existing", "日期切换后发现已有记录，已避开");
      }
      if (
        !(
          message.hours >= 0.5 &&
          message.hours <= 8 &&
          (message.hours * 2) % 1 === 0
        ) ||
        !proof
      )
        throw Error("时长或证明图片有误。");
      fill(field, String(message.hours));
      if (notes) {
        Object.getOwnPropertyDescriptor(
          HTMLTextAreaElement.prototype,
          "value",
        ).set.call(notes, message.notes || "");
        notes.dispatchEvent(new Event("input", { bubbles: true }));
      }
      const input = form.querySelector('input[type="file"]');
      if (!input) throw Error("无法识别官网的证明上传入口。");
      const binary = atob(proof.base64);
      const file = new File(
        [Uint8Array.from(binary, (c) => c.charCodeAt(0))],
        proof.name,
        { type: proof.type },
      );
      const transfer = new DataTransfer();
      transfer.items.add(file);
      input.files = transfer.files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      const uploaded = await waitStable(
        () =>
          form.querySelector(".ant-upload-list-item-done") &&
          !form.querySelector(
            ".ant-upload-list-item-uploading,.ant-upload-list-item-error",
          ) &&
          !isLoading(form),
        timing.submit,
        350,
      );
      if (!uploaded) throw Error("证明图片尚未上传成功，请检查后继续。");
      const confirm = find(form, "button", "确定");
      if (
        changed(message.target) ||
        Number(field.value) !== message.hours ||
        !enabled(confirm)
      )
        throw Error("提交前核对未通过。");
      clicked = true;
      const recorded = await submitAndWait(
        form,
        confirm,
        () => changed(message.target),
        (element, text) => {
          if (
            element.querySelector(".ant-message-success") ||
            element.matches(".ant-message-success") ||
            /^(成功|操作成功|录入成功|保存成功)$/.test(text)
          )
            return result("added", "官网确认时长录入成功");
          return null;
        },
      );
      return (
        recorded ||
        result("unknown", "未能确认时长结果，请核对这个人的日期记录")
      );
    } catch (error) {
      if (!clicked && form) await close(form);
      return result(
        clicked ? "unknown" : error.personIssue ? "rejected" : "blocked",
        error.message || "官网计时操作暂不可用",
      );
    } finally {
      busy = false;
    }
  }
  globalThis.__buaaHoursAdapter = {
    handle,
    target,
    changed,
    close,
    scanDates,
    getProof: () => proof,
  };
  if (typeof chrome !== "undefined" && chrome.runtime?.id)
    chrome.runtime.onMessage.addListener((message, sender, respond) => {
      if (
        sender.id !== chrome.runtime.id ||
        !sender.url?.startsWith(chrome.runtime.getURL("hours.html")) ||
        !message.type?.startsWith("hours-")
      )
        return false;
      handle(message).then(respond, () =>
        respond(result("unknown", "计时结果无法确认")),
      );
      return true;
    });
})();
